const foods = [
	{
		id : 1,
		food : "Rice",
		Calories : 50,
		Quantity : 1
	},
	{
		id : 2,
		food : "Roti",
		Calories : 80,
		Quantity : 1
	},
	{
		id : 3,
		food : "Apple",
		Calories : 100,
		Quantity : 1
	},
	{
		id : 4,
		food : "Orange",
		Calories : 120,
		Quantity : 1
	}
]

const activity = [
	{
		id : 1,
		activity : "Running",
		step : 1,
		calories_burned : 10
	},
	{
		id : 1,
		activity : "Walking",
		step : 1,
		calories_burned : 15
	}
]